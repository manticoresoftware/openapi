# Manticoresearch.JoinCond

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**field** | **String** | Field to join on | 
**table** | **String** | Joined table | 
**type** | **Object** |  | [optional] 


