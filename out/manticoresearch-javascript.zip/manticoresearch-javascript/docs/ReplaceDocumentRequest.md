# Manticoresearch.ReplaceDocumentRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**doc** | **Object** | Object containing the new document data to replace the existing one. | 


