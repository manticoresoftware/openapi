# Manticoresearch.Match

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **String** |  | 
**operator** | **String** |  | [optional] 
**boost** | **Number** |  | [optional] 



## Enum: OperatorEnum


* `or` (value: `"or"`)

* `and` (value: `"and"`)




