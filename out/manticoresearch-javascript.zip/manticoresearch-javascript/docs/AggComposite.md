# Manticoresearch.AggComposite

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**size** | **Number** | Maximum number of composite buckets in the result | [optional] 
**sources** | **[{String: AggCompositeSource}]** |  | [optional] 


