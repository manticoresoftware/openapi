# Manticoresearch.AggCompositeTerm

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**field** | **String** | Name of field to operate with | 


