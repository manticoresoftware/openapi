# Manticoresearch.JoinOn

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**right** | [**JoinCond**](JoinCond.md) |  | [optional] 
**left** | [**JoinCond**](JoinCond.md) |  | [optional] 
**operator** | **String** |  | [optional] 



## Enum: OperatorEnum


* `eq` (value: `"eq"`)




