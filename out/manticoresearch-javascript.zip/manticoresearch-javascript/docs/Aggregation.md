# Manticoresearch.Aggregation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terms** | [**AggTerms**](AggTerms.md) |  | [optional] 
**sort** | **[Object]** |  | [optional] 
**composite** | [**AggComposite**](AggComposite.md) |  | [optional] 


