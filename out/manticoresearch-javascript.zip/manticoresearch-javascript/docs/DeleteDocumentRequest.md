# Manticoresearch.DeleteDocumentRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**index** | **String** | Index name | 
**cluster** | **String** | Cluster name | [optional] 
**id** | **Number** | The ID of document for deletion | [optional] 
**query** | **Object** | Defines the criteria to match documents for deletion | [optional] 


