# Manticoresearch.AggTerms

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**field** | **String** | Name of attribute to aggregate by | 
**size** | **Number** | Maximum number of buckets in the result | [optional] 


