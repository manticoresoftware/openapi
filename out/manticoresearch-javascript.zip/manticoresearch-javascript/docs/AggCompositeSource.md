# Manticoresearch.AggCompositeSource

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terms** | [**AggCompositeTerm**](AggCompositeTerm.md) |  | 


