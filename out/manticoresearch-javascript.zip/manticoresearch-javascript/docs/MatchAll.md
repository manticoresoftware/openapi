# Manticoresearch.MatchAll

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**all** | **String** |  | 



## Enum: AllEnum


* `{}` (value: `"{}"`)




