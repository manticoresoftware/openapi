# Manticoresearch.PercolateRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | [**PercolateRequestQuery**](PercolateRequestQuery.md) |  | 


