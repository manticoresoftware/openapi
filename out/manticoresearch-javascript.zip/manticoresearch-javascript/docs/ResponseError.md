# Manticoresearch.ResponseError

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **Object** | Type or category of the error | 
**reason** | **Object** | Detailed explanation of why the error occurred | [optional] 
**index** | **Object** | The index related to the error, if applicable | [optional] 


