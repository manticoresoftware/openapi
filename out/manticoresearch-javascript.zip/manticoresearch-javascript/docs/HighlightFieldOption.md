# Manticoresearch.HighlightFieldOption

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fragmentSize** | **Number** | Maximum size of the text fragments in highlighted snippets per field | [optional] 
**limit** | **Number** | Maximum size of snippets per field | [optional] 
**limitSnippets** | **Number** | Maximum number of snippets per field | [optional] 
**limitWords** | **Number** | Maximum number of words per field | [optional] 
**numberOfFragments** | **Number** | Total number of highlighted fragments per field | [optional] 


