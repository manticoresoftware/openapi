# Manticoresearch.ErrorResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | [**ResponseError**](ResponseError.md) |  | 
**status** | **Number** | HTTP status code of the error response | [optional] [default to 500]


