# Manticoresearch.Range

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lt** | **Object** |  | [optional] 
**lte** | **Object** |  | [optional] 
**gt** | **Object** |  | [optional] 
**gte** | **Object** |  | [optional] 


