# ManticoreSearch.Model.Aggregation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Terms** | [**AggTerms**](AggTerms.md) |  | [optional] 
**Sort** | **List&lt;Object&gt;** |  | [optional] 
**Composite** | [**AggComposite**](AggComposite.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

