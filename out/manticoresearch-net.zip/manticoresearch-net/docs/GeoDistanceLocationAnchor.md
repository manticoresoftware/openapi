# ManticoreSearch.Model.GeoDistanceLocationAnchor
Specifies the location of the pin point used for search

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Lat** | **Object** | Latitude of the anchor point | [optional] 
**Lon** | **Object** | Longitude of the anchor point | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

