# ManticoreSearch.Model.JoinCond
Object representing the conditions used to perform the join operation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Field** | **string** | Field to join on | 
**Table** | **string** | Joined table | 
**Type** | **Object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

