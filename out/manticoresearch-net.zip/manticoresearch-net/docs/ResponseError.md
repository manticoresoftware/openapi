# ManticoreSearch.Model.ResponseError

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | **Object** | Type or category of the error | 
**Reason** | **Object** | Detailed explanation of why the error occurred | [optional] 
**Index** | **Object** | The index related to the error, if applicable | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

