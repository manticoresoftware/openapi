# ManticoreSearch.Model.AggTerms
Object containing term fields to aggregate on

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Field** | **string** | Name of attribute to aggregate by | 
**Size** | **int** | Maximum number of buckets in the result | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

