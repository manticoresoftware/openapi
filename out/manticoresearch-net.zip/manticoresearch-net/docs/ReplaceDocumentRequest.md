# ManticoreSearch.Model.ReplaceDocumentRequest
Object containing the document data for replacing an existing document in an index.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Doc** | **Object** | Object containing the new document data to replace the existing one. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

