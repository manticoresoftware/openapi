# ManticoreSearch.Model.JoinOn

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Right** | [**JoinCond**](JoinCond.md) |  | [optional] 
**Left** | [**JoinCond**](JoinCond.md) |  | [optional] 
**VarOperator** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

