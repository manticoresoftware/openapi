# ManticoreSearch.Model.AggCompositeSource
Object containing terms used for composite aggregation.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Terms** | [**AggCompositeTerm**](AggCompositeTerm.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

