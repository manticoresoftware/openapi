# ManticoreSearch.Model.Range
Filter helper object defining the 'range' condition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Lt** | **Object** |  | [optional] 
**Lte** | **Object** |  | [optional] 
**Gt** | **Object** |  | [optional] 
**Gte** | **Object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

