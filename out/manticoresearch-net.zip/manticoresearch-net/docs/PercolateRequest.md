# ManticoreSearch.Model.PercolateRequest
Object containing the query for percolating documents against stored queries in a percolate index

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Query** | [**PercolateRequestQuery**](PercolateRequestQuery.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

