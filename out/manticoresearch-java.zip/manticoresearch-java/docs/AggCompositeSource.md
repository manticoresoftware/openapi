

# AggCompositeSource

Object containing terms used for composite aggregation.

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**terms** | [**AggCompositeTerm**](AggCompositeTerm.md) |  |  |



