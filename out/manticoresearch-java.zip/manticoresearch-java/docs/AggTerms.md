

# AggTerms

Object containing term fields to aggregate on

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**field** | **String** | Name of attribute to aggregate by |  |
|**size** | **Integer** | Maximum number of buckets in the result |  [optional] |



