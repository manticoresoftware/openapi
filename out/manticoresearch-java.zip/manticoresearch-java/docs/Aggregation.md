

# Aggregation


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**terms** | [**AggTerms**](AggTerms.md) |  |  [optional] |
|**sort** | **List&lt;Object&gt;** |  |  [optional] |
|**composite** | [**AggComposite**](AggComposite.md) |  |  [optional] |



