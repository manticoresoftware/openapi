

# GeoDistanceLocationAnchor

Specifies the location of the pin point used for search

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**lat** | **Object** | Latitude of the anchor point |  [optional] |
|**lon** | **Object** | Longitude of the anchor point |  [optional] |



