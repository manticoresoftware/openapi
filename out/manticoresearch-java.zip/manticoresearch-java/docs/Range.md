

# Range

Filter helper object defining the 'range' condition

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**lt** | **Object** |  |  [optional] |
|**lte** | **Object** |  |  [optional] |
|**gt** | **Object** |  |  [optional] |
|**gte** | **Object** |  |  [optional] |



