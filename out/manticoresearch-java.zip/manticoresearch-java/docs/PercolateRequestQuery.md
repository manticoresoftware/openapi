

# PercolateRequestQuery


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**percolate** | **Object** | Object representing the document to percolate |  |



