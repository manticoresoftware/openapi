

# ReplaceDocumentRequest

Object containing the document data for replacing an existing document in an index.

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**doc** | **Object** | Object containing the new document data to replace the existing one. |  |



