

# ErrorResponse

Error response object containing information about the error and a status code

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**error** | [**ResponseError**](ResponseError.md) |  |  |
|**status** | **Integer** | HTTP status code of the error response |  [optional] |



