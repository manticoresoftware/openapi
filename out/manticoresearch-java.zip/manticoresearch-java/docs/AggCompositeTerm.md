

# AggCompositeTerm

Object representing a term to be used in composite aggregation.

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**field** | **String** | Name of field to operate with |  |



