

# SourceRules

Defines which fields to include or exclude in the response for a search query

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**includes** | **Object** | List of fields to include in the response |  [optional] |
|**excludes** | **Object** | List of fields to exclude from the response |  [optional] |



