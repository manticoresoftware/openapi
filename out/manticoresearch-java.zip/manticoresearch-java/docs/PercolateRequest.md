

# PercolateRequest

Object containing the query for percolating documents against stored queries in a percolate index

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**query** | [**PercolateRequestQuery**](PercolateRequestQuery.md) |  |  |



