

# JoinOn


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**right** | [**JoinCond**](JoinCond.md) |  |  [optional] |
|**left** | [**JoinCond**](JoinCond.md) |  |  [optional] |
|**operator** | [**OperatorEnum**](#OperatorEnum) |  |  [optional] |



## Enum: OperatorEnum

| Name | Value |
|---- | -----|
| EQ | &quot;eq&quot; |



