

# MatchAll

Filter helper object defining the 'match all'' condition

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**all** | [**AllEnum**](#AllEnum) |  |  |



## Enum: AllEnum

| Name | Value |
|---- | -----|
| _ | &quot;{}&quot; |



